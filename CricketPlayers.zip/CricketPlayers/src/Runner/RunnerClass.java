package Runner;

import Players.Player;
import Teams.SortByName;
import Teams.SortingAge;
import Teams.Team;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
;

public class RunnerClass {


    public static void main(String[] args) throws IOException {


        Team t = new Team("Cricket","players_data.txt");
        t.averageAge();
        t.skillDisplay();
        t.stateDisplay();
        t.sortByNames();
        t.sortByAge();
    }

}
